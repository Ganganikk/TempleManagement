 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sajjayana</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <section id="header"> 
        <a href="#"><img src="bicons.jpg" class="logo" alt=""></a> 
        <div>
             <ul id="navbar">
                <li><a class="active" href="v.offier.php">Home</a></li> 
                <li><a    href="c.php">Benificary Details</a></li>
                <li><a href="Upload.php">Upload report</a></li>
                 <li><a href="cs.php">Contact</a></li>
             </ul>
        </div>   
    </section>
    <section id="hero">
        <h1>Welcome</h1>
        <h2>This is a official website of Sajjayana</h2>
         <p> Embark on a sacred digital journey within the temple website<br> where every detail is meticulously preserved to enlighten and inspire</p>
     </section>
    <section id="Help" class="section-p1">
        <div class="fe-box">
            <img src="h1.jpg" alt="">
            <h6>Most venerable<br>thibbatuwawe sri siddaratha mahanayaka<br>thero<br>malwathtah chapter</h6>
        </div>
        <div class="fe-box">
            <img src="h2.jpg" alt="">
            <h6>Most venerable<br>warakagoda sri ganarathna mahanayaka<br>thero<br>Asgiriya chapter</h6>

         </div>
        <div class="fe-box">
            <img src="h3.jpg" alt="">
            <h6>Most venerable<br>warakagoda galagodagaathe mahanayaka<br>thero<br>Asgiriya chapter</h6>

         </div>
        <div class="fe-box">
            <img src="h4.jpg" alt="">
            <h6>Most venerable<br>warakagoda nyanasara mahanayaka<br>thero<br>Malwaththa chapter</h6>

         </div>
        <div class="fe-box">
            <img src="h5.jpg" alt="">
            <h6>Most venerable<br> galagodagaathe mahanayaka<br>thero<br>Asgiriya chapter</h6>

         </div>
        <div class="fe-box">
            <img src="h6.jpg" alt="">
            <h6>Most venerable<br> Waskaduwe shri subadhdhi <br>thero<br>Asgiriya chapter</h6>

         </div>
        <!-- More fe-box divs here -->
    </section> 
     <section id="blog">
        <div class="blog-box">
        <div class="blog.img">
            <img src="b1.jpg" alt="">
        </div>
        <div class="blog-details">
            <h4>Buddhism in Sri Lanka: A Journey Through Spirituality and Culture</h4>
            <p> Nepal is a land where spirituality and culture blend seamlessly, with Buddhism playing a pivotal role in shaping the nation’s ethos. The roots of Buddhism in Nepal stretch back to the very inception of the religion, making it a fascinating study of ancient traditions and contemporary practices. This exploration into Buddhism in Nepal offers insights into its historical significance, cultural integration, and the vibrant practices that continue to thrive.</p>
            <a href="a.html">Continue reading</a>
        </div>
            <h1>Spirituality</h1>
            
        </div>
        
        <div class="blog-box">
        <div class="blog.img">
            <img src="b2.jpg" alt="">
        </div>
        <div class="blog-details">
            <h4>Celebrations </h4>
            <p> Buddhist Celebrations

            Buddhism celebrates many holidays and festivals throughout the year. These celebrations are observed as a way of honoring important figures, moments, and themes in Buddhist tradition.

            The annual calendar within Buddhist communities is populated with holidays and festivals for reflection and gathering together. One of the most important Buddhist holidays is Vesak, also known as Buddha Day.

            It falls on the first full moon in May and commemorates Buddha’s birth, enlightenment, and death.</p>
            <a href="b.html">Continue reading</a>
        </div>
            <h1>Celebrations</h1>
            
        </div>
          <div class="blog-box">
        <div class="blog.img">
            <img src="b3.jpg" alt="">
        </div>
        <div class="blog-details">
            <h4> Puja Day </h4>
            <p>  Puja Day and Sangha Day
            This celebration usually occurs on the day of full moon in March. On this day, it is believed that the Buddha gave his disciples a message, called the "Ovadha Patimokha," and amazing things happened.

            One of these amazing events involved 1,250 of Buddha’s disciples coming to see him in the Magaha state capital to pay their respects; amazingly, Buddha had not summoned them there.

            The disciples gathered together to form the "Fourfold Assembly," because they all:</p>
            <a href="c.html">Continue reading</a>
        </div>
            <h1>Puja Day</h1>
            
        </div>
          <div class="blog-box">
        <div class="blog.img">
            <img src="b4.jpg" alt="">
        </div>
        <div class="blog-details">
            <h4>History</h4>
            <p> History of Buddhism
          The history of Buddhism begins with the life of Buddha, 25 centuries ago. It was founded on Hindu beliefs. </p>
            <a href="d.html">Continue reading</a>
        </div>
            <h1>History of Buddhism</h1>
            
        </div>
        <div class="blog-box">
        <div class="blog.img">
            <img src="b6.jpg" alt="">
        </div>
        <div class="blog-details">
            <h4> journy of Buddha</h4>
            <p> *Buddha's Birthday, also known as **Buddha Jayanti, **Buddha Purnima, and **Buddha Pournami, is a primarily Buddhist festival celebrated in most of South, Southeast, and East Asia.  </p>
            <a href="e.html">Continue reading</a>
        </div>
            <h1>Journy..</h1>
            
        </div>
          
 
          
    </section>

        <section id="audio">
        <audio controls>
            <p>Hi!drftgyhjkl</p>
            <br><source src="nt.mp3" type="audio/mpeg">
         </audio>
    </section>

     

    <footer class="section-p1"> 
    <div class="col"> 
        <img class="logo" src="ss.jpg" alt=""> 
        <h4>Contact</h4> 
        <p><strong>Address: </strong> 562 walpala road, Street 32, Imaduwa. </p> <p><strong>Phone:</strong> (+94) 0770891303 / (+91) 01 2345 6789</p> <p> </p> 
        <div class="follow"> 
            <h4>Follow us</h4> 
            <div class="icon"> 
            <i class="fab fa-facebook-f"></i> <i class="fab fa-twitter"></i> 
            <i class="fab fa-instagram"></i>  
             <i class="fab fa-youtube"></i> 
        </div> 
    </div> 
    
     
     
            <div class="copyright"> 
                <p>© 2024, Religious Website</p>  
            </div>

</footer>

    <script src="script.js"></script>
</body>
</html>


