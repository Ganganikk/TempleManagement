<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ToToo</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <section id="header"> 
        <a href="#"><img src="bicons.jpg" class="logo" alt=""></a> 
        <div>
            <ul id="navbar">
                <ul id="navbar">
                <li><a  href="Donator.html">Home</a></li> 
                <li><a    href="do.php">Donations</a></li>
                <li><a href="certificate.php">Cetificate</a></li>
                 <li><a class="active"  href="cs.php">Contact</a></li>
             </ul>
        </div>   
    </section>

    <section id="page-header" class="about-header">
       
        <h2>#let'talk</h2>
        
        <p>LEAVE A MESSAGE</p>
        
    </section>
    
    <section id="contact-details" class="section-p1">
        
        <div class="details">
            <span>GET IN TOUCH</span>
            <h2> contact us today</h2>
             <div>
                <li>
                    <i class="fal far-map"></i>
                    <p>64/paragoda streert batemulla,galle</p>
                </li>
                <li>
                    <i class="fal far-map"></i>
                    <p>contact@example.com</p>
                </li>
                <li>
                    <i class="fal far-map"></i>
                    <p>contact@example.com</p>
                </li>
                <li>
                    <i class="fal far-map"></i>
                    <p> monday to saturday:9am to 16pm</p>
                </li>
            </div>
            <div class="map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3967.7100961946867!2d80.37217127009667!3d6.034464615310514!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae16b854c7aa495%3A0x82ace25e3a03378f!2sParagoda%20Raja%20Maha%20Viharaya!5e0!3m2!1sen!2slk!4v1712487772587!5m2!1sen!2slk" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>"  
            </div>
        </div>
    </section>

     
    <section id="form-details" >
        <form>
            <span>
                Leave A Message
            </span>
             
            <input type="text" placeholder="Your name">
            <input type="text" placeholder="Your email">
            <input type="text" placeholder="Your subject">
            <textarea name=""  cols="30" rows="10" cols="30" placeholder="Your Message"></textarea>
            <button class="normal">Submit</button>
        </form>

        
         <div><img src="h2.jpg"alt="">
            <p><span>thibbatuwawe sri siddaratha mahanayaka</span> <br>phone:077 785 8521<br>Email"siddartha33@gmail.com"</p>
        
         <div><img src="h3.jpg"alt="">
            <p><span>Waskaduwe shri subadhdhi</span> <br>phone:076 492 8287<br>Email"shrii@gmail.com</p>
        </div>
         <div><img src="h1.jpg"alt="">
            <p><span> galagodagaathe mahanayaka</span> <br>phone:078 991 2256<br>Email"galagoda22@gmail.com</p>
        </div>
    
    </section>
   
    <section id="newsletter" class="section-p1 section-m1">  
    </section>

    <footer class="section-p1"> 
        <div class="col"> 
        <img class="logo" src="logo.png" alt=""> 
        <h4>Contact</h4> 
        <p><strong>Address: </strong> 64/5 walpala  Road, paragoda Street 32, batemulla</ p> <p><strong>Phone:</strong> (+94) 0770891303 / (+91) 01 2345 6789</p> <p><strong></p> 
         
        

</footer>

    <script src="script.js"></script>
</body>
</html>